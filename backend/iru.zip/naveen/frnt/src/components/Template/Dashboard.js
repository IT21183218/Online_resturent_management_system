import React from 'react'
import styles from './Dashboard.module.scss'
import DashboardManagement from './Pictures/Dashboard.png'
import AccountManagement from './Pictures/AccountManagement.png'
import SiteManagement from './Pictures/SiteManagement.png'
import EquipmentManagement from './Pictures/EquipmentManagement.png'
import FinanceManagement from './Pictures/FinanceManagement.png'
import HRManagement from './Pictures/HRManagement.png'
import TransportManagement from './Pictures/TransportManagement.png'
import CustomerManagement from './Pictures/CustomerManagement.png'
import PackageManagement from './Pictures/PackageManagement.png'


export default function Dashboard() {

  return (

    <div>

      <div className="w-36 h-max fixed -top-16 3xl:top-32 max-2xl:left-7 bg-white rounded-3xl pt-2 pb-2 pl-3 pr-3 max-3xl:scale-65 flex-col flex 
       items-center max-2xl:scale-54 max-3xl:-top-20 3xl:left-32 mr-7 2xl:-top-8 2xl:left-20 ">
            
        <div className={styles.DashIconWrapper}>
          <img src={DashboardManagement} alt='DashboardManagement' />
          <span className={styles.SectionNames} >Dashboard</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={FinanceManagement} alt='FinanceManagement' />
          <span className={styles.SectionNames} >Finance</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={SiteManagement} alt='SiteManagement' />
          <span className={styles.SectionNames} >Sites</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={EquipmentManagement} alt='EquipmentManagement' />
          <span className={styles.SectionNames} >Equipments</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={CustomerManagement} alt='CustomerManagement' />
          <span className={styles.SectionNames} >Customers</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={HRManagement} alt='HRManagement' />
          <span className={styles.SectionNames} >HR</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={PackageManagement} alt='PackageManagement' />
          <span className={styles.SectionNames} >Packages</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={TransportManagement} alt='TransportManagement' />
          <span className={styles.SectionNames} >Transport</span>
        </div>

        <div className={styles.DashIconWrapper}>
          <img src={AccountManagement} alt='AccountManagement' />
          <span className={styles.SectionNames} >Accounts</span>
        </div>

      </div>

    </div>
  )
}

